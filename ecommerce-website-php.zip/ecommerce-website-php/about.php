<?php

session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>

  <main>
    <!-- HERO -->
    <div class="nero">
      <div class="nero__heading">
        <span class="nero__bold">About</span> us
      </div>
      <p class="nero__text">
      </p>
    </div>
  </main>
  
  

<div id="content" ><!-- content Starts -->
<div class="container" ><!-- container Starts -->

<div class="col-md-12" ><!-- col-md-12 Starts -->

<div class="box" ><!-- box Starts -->

<?php

$get_about_us = "select * from about_us";

$run_about_us = mysqli_query($con,$get_about_us);

$row_about_us = mysqli_fetch_array($run_about_us);

$about_heading = $row_about_us['about_heading'];

$about_short_desc = $row_about_us['about_short_desc'];

$about_desc = $row_about_us['about_desc'];

?>




			<p style="text-align: center;">
 <img alt="company" src="https://i.imgur.com/fAQsTiU.png" height="480" class="img-responsive">
</p>
<p>
</p>
<p>
 <b>Active&nbsp;Solutions</b>&nbsp;2013-ci ildən kommersiya, dövlət və sənaye obyektləri üçün təhlükəsizlik sistemlərinin layihələndirilməsi, quraşdırılmasını və texniki dəstəyi üzrə fəaliyyət göstərir. Biz yalnız sistemlərin satışına deyil, həm də satış sonrası xidmətinə xüsusi diqqət yetiririk..<br>
 <br>
 <b>Strategiya</b><br>
	 Şirkət yarandığı gündən etibarən bazarın daim təhlilinə, mövcud və potensial müştərilərin mümkün tələbatlarını müəyyənləşdirməyə, yeni məhsulların tətbiqi və istehsalat fəaliyyətinin təkmilləşdirilməsinə xüsusi önəm vermişdir.Biz sadəcə olaraq məhsullarımızı satmağa çalışmırıq, qiymət/keyfiyyət nisbəti baxımından ən optimal həlli tapmağa səy göstəririk.<br>
 <br>
 <b>Partnyorlar</b><br>
	 Müvəffəqiyyətli işlər üçün şirkətimiz təhlükəsizlik sistemləri istehsalçıları ilə sıx və güclü əlaqələr yaradır.Tərəfdaşlarımızın adları və böyüklüyü, şirkətimizin korporativ dəyərlərə və innovasiyaya olan tutumunun bir göstəricisidir.<br>
 <br>
 <b>Komanda</b><br>
	 Şirkətimiz yüzlərlə uğurlu layihəyə imza atan və çoxillik təcrübəyə malik mühəndislərlə əməkdaşlıq edir.Həmçinin əməkdaşlarımız təhlükəsizlik sistemlərinin istehsalçılarından, onların peşəkar bacarıqlarının yekun təsdiqləməsi ilə əlaqədar xüsusi təlim keçmişdirlər.<br>
 <br>
 <b>Rəqabət üstünlüklərimiz nələrdir.</b><br>
 <br>
	 Biz işlərin yerinə yetirilməsi üçün müştəriyə tam məsuliyyət daşıyan komandayıq və işlərin yerinə yetirilmə müddətlərini peşəkar şəkildə idarə edirik.Eyni zamanda böyük layihələri həyata keçirmək üçün kifayət güclü maddi-texniki bazamız mövcuddur.<br>
 <br>
	 Paralel olaraq biz şirkətin intellektual və texniki bazasının inkişafına böyük sərmayələr qoyuruq.Bütün əməkdaşlarımızın mütəmadi olaraq peşəkar inkişafını təmin edirik.Eyni zamanda daim qabaqcıl istehsalçılarla əməkdaşlıq edərək müştərilərimizə yüksək keyfiyyətli və optimal həllər təklif edirik.
</p>						

</div><!-- box Ends -->

</div><!-- col-md-12 Ends -->



</div><!-- container Ends -->
</div><!-- content Ends -->



<?php

include("includes/footer.php");

?>

<script src="js/jquery.min.js"> </script>

<script src="js/bootstrap.min.js"></script>




</body>
</html>
